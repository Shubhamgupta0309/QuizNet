package com.project.quiznet;

public class QuestionAnswer {

    public static String question[] ={
            "Which keyword is used to declare a constant in Java?",
            "Which data structure in Java stores elements in a last-in, first-out (LIFO) manner??",
            "Which access modifier in Java allows a class or method to be accessible from any other class?",
            "What is the Java keyword used to handle exceptions?",
            "Which of the following Java data types is used to store a single 16-bit Unicode character?",
            "What is the Java keyword used to explicitly throw an exception?"
    };

    public static String choices[][] = {
            {"var","final","static","constant"},
            {"Queue","Set","List","Stack"},
            {"private","protected","public","default"},
            {"try","throw","catch","exception"},
            {"byte","char","int","short"},
            {"finally","try","catch","throw"}
    };

    public static String correctAnswers[] = {
            "final",
            "Stack",
            "public",
            "try",
            "char",
            "throw"
    };

}
